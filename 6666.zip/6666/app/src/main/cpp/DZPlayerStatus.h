//
// Created by hcDarren on 2019/6/23.
//

#ifndef MUSICPLAYER_DZPLAYERSTATUS_H
#define MUSICPLAYER_DZPLAYERSTATUS_H


class DZPlayerStatus {
public:
    /**
     * 是否退出，打算用这个变量来做退出(销毁)
     */
    bool isExit = false;
};


#endif //MUSICPLAYER_DZPLAYERSTATUS_H
