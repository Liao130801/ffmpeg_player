package com.example.a6666;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class MainActivity extends Activity {

    private static final String TAG = "FFMPEG";




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.activity_main);
        Button m=findViewById(R.id.dong);
        Animation t= AnimationUtils.loadAnimation(this,R.anim.view_animation);
        m.startAnimation(t);


    /**
     * 停止播放
     * @param view
     */}

    public void tiao(View view) {
        Intent intent=new Intent(MainActivity.this,newActivity.class);
        startActivity(intent);
    }
    public void tiaovideo(View view) {
        Intent intent=new Intent(MainActivity.this,LocalVideoListActivity.class);
        startActivity(intent);
    }
    public void down(View view) {
        String url = "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4";

        final String fileName = url.split("/")[url.split("/").length - 1];
        OkHttpClient client = new OkHttpClient();
        final Request request = new Request.Builder()
                .get()
                .url(url)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("moer", "onFailure: ");;
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //  String dirName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/LungFile";
                String dirName = "/storage/emulated/0/Pictures/Screenshots";
                File file=new File(dirName);
                if (!file.exists()) {
                    file.mkdir();
                }
                if (response != null) {
                    InputStream is = response.body().byteStream();
                    FileOutputStream fos = new FileOutputStream(new File(dirName + "/" + fileName));
                    int len = 0;
                    byte[] buffer = new byte[2048];
                    while (-1 != (len = is.read(buffer))) {
                        fos.write(buffer, 0, len);
                    }
                    fos.flush();
                    fos.close();
                    is.close();
                }
            }
        });

    }
}
