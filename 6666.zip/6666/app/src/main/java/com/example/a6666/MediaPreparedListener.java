package com.example.a6666;

/**
 * Created by hcDarren on 2019/6/16.
 * 错误回调
 */
public interface MediaPreparedListener {
    void onPrepared();
}
