package com.example.a6666;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.io.File;

public class newActivity extends AppCompatActivity {
    private File mVideoFile = new File("/storage/emulated/0/Pictures/2.mp4");
    private DZVideoView mVideoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.v);

        mVideoView = findViewById(R.id.video_view);
        Intent intent=getIntent();
        Bundle data=intent.getExtras();
        String path=data.getString("url");

        mVideoView.play(path);
    }




}
